print("Programa que demuestra la propiedad de cerradura en una suma")
print("La suma de dos números enteros siempre es un número entero")
print("")

num1 = int(input("Ingrese el primer numero: "))
num2 = int(input("Ingrese el segundo numero: "))

print("La suma de los dos numeros ingresados ({} + {}) es {}".format(num1, num2, num1+num2))